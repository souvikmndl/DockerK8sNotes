package httpapi

import (
	"context"
	"crypto/rand"
	"encoding/hex"
	"log/slog"
	"net/http"
	"strconv"
	"time"

	"github.com/souvik/search-service/internal/observability"
)

type ctxKey string

const requestIDKey ctxKey = "request_id"

// requestID attaches a unique id to each request for log correlation.
func requestID(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		b := make([]byte, 8)
		_, _ = rand.Read(b)
		id := hex.EncodeToString(b)
		w.Header().Set("X-Request-Id", id)
		ctx := context.WithValue(r.Context(), requestIDKey, id)
		next.ServeHTTP(w, r.WithContext(ctx))
	})
}

type statusRecorder struct {
	http.ResponseWriter
	status int
}

func (s *statusRecorder) WriteHeader(code int) { s.status = code; s.ResponseWriter.WriteHeader(code) }

// observe records RED metrics + a structured access log per request.
func observe(m *observability.Metrics) func(http.Handler) http.Handler {
	return func(next http.Handler) http.Handler {
		return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			start := time.Now()
			rec := &statusRecorder{ResponseWriter: w, status: 200}
			next.ServeHTTP(rec, r)

			dur := time.Since(start).Seconds()
			status := strconv.Itoa(rec.status)
			route := r.Method + " " + r.URL.Path
			m.RequestDuration.WithLabelValues(r.Method, r.URL.Path, status).Observe(dur)
			m.RequestsTotal.WithLabelValues(r.Method, r.URL.Path, status).Inc()

			id, _ := r.Context().Value(requestIDKey).(string)
			slog.Info("request",
				"request_id", id, "route", route, "status", rec.status,
				"duration_ms", time.Since(start).Milliseconds())
		})
	}
}

// recoverPanic turns a panic into a 500 instead of crashing the server.
func recoverPanic(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		defer func() {
			if err := recover(); err != nil {
				slog.Error("panic recovered", "err", err)
				http.Error(w, "internal error", http.StatusInternalServerError)
			}
		}()
		next.ServeHTTP(w, r)
	})
}
