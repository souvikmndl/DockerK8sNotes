// Package httpapi wires routes, middleware, and the search/document handlers.
package httpapi

import (
	"context"
	"encoding/json"
	"log/slog"
	"net/http"
	"time"

	"github.com/prometheus/client_golang/prometheus/promhttp"
	"github.com/souvik/search-service/internal/db"
	"github.com/souvik/search-service/internal/observability"
)

type API struct {
	pools   *db.Pools
	metrics *observability.Metrics
}

type Document struct {
	ID    int64   `json:"id"`
	Title string  `json:"title"`
	Body  string  `json:"body"`
	Rank  float64 `json:"rank,omitempty"`
}

func New(pools *db.Pools, m *observability.Metrics) http.Handler {
	a := &API{pools: pools, metrics: m}
	mux := http.NewServeMux()
	mux.HandleFunc("GET /healthz", a.healthz) // liveness: process only
	mux.HandleFunc("GET /readyz", a.readyz)   // readiness: DB reachable
	mux.HandleFunc("POST /documents", a.addDocument)
	mux.HandleFunc("GET /search", a.search)
	mux.Handle("GET /metrics", promhttp.Handler())

	// middleware chain: request-id -> logging+metrics -> recover
	return requestID(observe(a.metrics)(recoverPanic(mux)))
}

func (a *API) healthz(w http.ResponseWriter, _ *http.Request) { writeText(w, 200, "ok") }

func (a *API) readyz(w http.ResponseWriter, r *http.Request) {
	if err := a.pools.Ping(r.Context()); err != nil {
		writeText(w, http.StatusServiceUnavailable, "db not ready")
		return
	}
	writeText(w, 200, "ready")
}

func (a *API) addDocument(w http.ResponseWriter, r *http.Request) {
	var d Document
	if err := json.NewDecoder(r.Body).Decode(&d); err != nil || d.Title == "" || d.Body == "" {
		writeErr(w, http.StatusBadRequest, "title and body required")
		return
	}
	ctx, cancel := context.WithTimeout(r.Context(), 3*time.Second)
	defer cancel()
	// writes go to the WRITER pool
	err := a.pools.Writer.QueryRow(ctx,
		`INSERT INTO documents (title, body) VALUES ($1,$2) RETURNING id`,
		d.Title, d.Body).Scan(&d.ID)
	if err != nil {
		slog.Error("insert failed", "err", err)
		writeErr(w, http.StatusInternalServerError, "insert failed")
		return
	}
	writeJSON(w, http.StatusCreated, d)
}

func (a *API) search(w http.ResponseWriter, r *http.Request) {
	q := r.URL.Query().Get("q")
	if q == "" {
		writeErr(w, http.StatusBadRequest, "q is required")
		return
	}
	ctx, cancel := context.WithTimeout(r.Context(), 3*time.Second)
	defer cancel()
	// reads go to the READER pool (Aurora replicas)
	rows, err := a.pools.Reader.Query(ctx,
		`SELECT id, title, body,
		        ts_rank(search_vector, websearch_to_tsquery('english',$1)) AS rank
		   FROM documents
		  WHERE search_vector @@ websearch_to_tsquery('english',$1)
		  ORDER BY rank DESC LIMIT 20`, q)
	if err != nil {
		slog.Error("query failed", "err", err)
		writeErr(w, http.StatusInternalServerError, "query failed")
		return
	}
	defer rows.Close()

	out := []Document{}
	for rows.Next() {
		var d Document
		if err := rows.Scan(&d.ID, &d.Title, &d.Body, &d.Rank); err != nil {
			writeErr(w, http.StatusInternalServerError, "scan failed")
			return
		}
		out = append(out, d)
	}
	writeJSON(w, http.StatusOK, map[string]any{"query": q, "results": out})
}

func writeJSON(w http.ResponseWriter, code int, v any) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(code)
	_ = json.NewEncoder(w).Encode(v)
}
func writeErr(w http.ResponseWriter, code int, msg string) {
	writeJSON(w, code, map[string]string{"error": msg})
}
func writeText(w http.ResponseWriter, code int, s string) {
	w.WriteHeader(code)
	_, _ = w.Write([]byte(s))
}
