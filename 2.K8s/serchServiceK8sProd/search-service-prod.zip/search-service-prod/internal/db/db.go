// Package db manages the writer/reader connection pools to Aurora PostgreSQL over TLS.
package db

import (
	"context"
	"fmt"
	"time"

	"github.com/jackc/pgx/v5/pgxpool"
	"github.com/souvik/search-service/internal/config"
)

// Pools holds separate pools so reads can target Aurora replicas via the reader endpoint.
type Pools struct {
	Writer *pgxpool.Pool
	Reader *pgxpool.Pool
}

func Open(ctx context.Context, cfg *config.Config) (*Pools, error) {
	writer, err := newPool(ctx, cfg, cfg.WriterHost)
	if err != nil {
		return nil, fmt.Errorf("writer pool: %w", err)
	}
	reader, err := newPool(ctx, cfg, cfg.ReaderHost)
	if err != nil {
		writer.Close()
		return nil, fmt.Errorf("reader pool: %w", err)
	}
	return &Pools{Writer: writer, Reader: reader}, nil
}

func (p *Pools) Close() {
	p.Reader.Close()
	p.Writer.Close()
}

// Ping verifies the writer is reachable (used by the readiness probe).
func (p *Pools) Ping(ctx context.Context) error {
	ctx, cancel := context.WithTimeout(ctx, 2*time.Second)
	defer cancel()
	return p.Writer.Ping(ctx)
}

func newPool(ctx context.Context, cfg *config.Config, host string) (*pgxpool.Pool, error) {
	// verify-full = encrypt AND verify the server certificate against the RDS CA bundle.
	dsn := fmt.Sprintf(
		"postgres://%s:%s@%s:5432/%s?sslmode=verify-full&sslrootcert=%s",
		cfg.DBUser, cfg.DBPassword, host, cfg.DBName, cfg.SSLRootCA,
	)
	pc, err := pgxpool.ParseConfig(dsn)
	if err != nil {
		return nil, err
	}
	pc.MaxConns = 20
	pc.MinConns = 2
	pc.MaxConnIdleTime = 5 * time.Minute
	pc.HealthCheckPeriod = 30 * time.Second

	ctx, cancel := context.WithTimeout(ctx, 10*time.Second)
	defer cancel()
	return pgxpool.NewWithConfig(ctx, pc)
}
