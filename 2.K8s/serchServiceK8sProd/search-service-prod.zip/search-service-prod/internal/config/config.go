// Package config loads and validates runtime configuration from the environment.
package config

import (
	"fmt"
	"log/slog"
	"os"
	"strings"
)

type Config struct {
	Port       string
	LogLevel   slog.Level
	DBUser     string
	DBPassword string
	DBName     string
	WriterHost string // Aurora cluster (writer) endpoint
	ReaderHost string // Aurora reader endpoint
	SSLRootCA  string // path to the RDS CA bundle inside the image
}

// Load reads env vars, validates required ones, and fails fast on error.
func Load() (*Config, error) {
	c := &Config{
		Port:       envOr("PORT", "8080"),
		DBUser:     os.Getenv("DB_USER"),
		DBPassword: os.Getenv("DB_PASSWORD"),
		DBName:     os.Getenv("DB_NAME"),
		WriterHost: os.Getenv("DB_WRITER_HOST"),
		ReaderHost: os.Getenv("DB_READER_HOST"),
		SSLRootCA:  envOr("DB_SSL_ROOT_CA", "/etc/ssl/rds/global-bundle.pem"),
		LogLevel:   parseLevel(envOr("LOG_LEVEL", "info")),
	}
	// The reader defaults to the writer if a single-instance DB is used.
	if c.ReaderHost == "" {
		c.ReaderHost = c.WriterHost
	}
	var missing []string
	for k, v := range map[string]string{
		"DB_USER": c.DBUser, "DB_PASSWORD": c.DBPassword,
		"DB_NAME": c.DBName, "DB_WRITER_HOST": c.WriterHost,
	} {
		if v == "" {
			missing = append(missing, k)
		}
	}
	if len(missing) > 0 {
		return nil, fmt.Errorf("missing required env vars: %s", strings.Join(missing, ", "))
	}
	return c, nil
}

func envOr(k, def string) string {
	if v := os.Getenv(k); v != "" {
		return v
	}
	return def
}

func parseLevel(s string) slog.Level {
	switch strings.ToLower(s) {
	case "debug":
		return slog.LevelDebug
	case "warn":
		return slog.LevelWarn
	case "error":
		return slog.LevelError
	default:
		return slog.LevelInfo
	}
}
