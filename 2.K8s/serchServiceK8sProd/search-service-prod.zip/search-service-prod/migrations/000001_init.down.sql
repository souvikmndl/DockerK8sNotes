DROP INDEX IF EXISTS idx_documents_search;
DROP TABLE IF EXISTS documents;
