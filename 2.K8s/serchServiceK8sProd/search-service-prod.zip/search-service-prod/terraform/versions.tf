terraform {
  required_version = ">= 1.7"
  required_providers {
    aws        = { source = "hashicorp/aws",       version = "~> 5.60" }
    kubernetes = { source = "hashicorp/kubernetes", version = "~> 2.31" }
    helm       = { source = "hashicorp/helm",       version = "~> 2.14" }
    random     = { source = "hashicorp/random",     version = "~> 3.6" }
  }
  # Remote state — create the bucket + lock table out of band, then uncomment:
  # backend "s3" {
  #   bucket         = "my-tfstate-bucket"
  #   key            = "search-service/prod.tfstate"
  #   region         = "ap-south-1"
  #   dynamodb_table = "tf-locks"
  #   encrypt        = true
  # }
}
