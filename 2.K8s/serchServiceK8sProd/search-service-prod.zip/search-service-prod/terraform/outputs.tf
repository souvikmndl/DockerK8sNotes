output "cluster_name"           { value = module.eks.cluster_name }
output "cluster_endpoint"       { value = module.eks.cluster_endpoint }
output "ecr_repository_url"     { value = aws_ecr_repository.app.repository_url }
output "aurora_writer_endpoint" { value = module.aurora.cluster_endpoint }
output "aurora_reader_endpoint" { value = module.aurora.cluster_reader_endpoint }
output "app_irsa_role_arn"      { value = module.irsa_app.iam_role_arn }
output "kubeconfig_command" {
  value = "aws eks update-kubeconfig --name ${module.eks.cluster_name} --region ${var.region}"
}
