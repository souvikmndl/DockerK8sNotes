resource "random_password" "db" {
  length  = 32
  special = false
}

module "aurora" {
  source  = "terraform-aws-modules/rds-aurora/aws"
  version = "~> 9.10"

  name           = var.cluster_name
  engine         = "aurora-postgresql"
  engine_version = "16.4"

  instances = {
    writer = { instance_class = "db.r6g.large" }
    reader = { instance_class = "db.r6g.large" }   # Multi-AZ read replica
  }

  vpc_id               = module.vpc.vpc_id
  db_subnet_group_name = module.vpc.database_subnet_group_name

  # Only the EKS node security group can reach Postgres.
  security_group_rules = {
    ingress_from_nodes = {
      type                     = "ingress"
      from_port                = 5432
      to_port                  = 5432
      protocol                 = "tcp"
      source_security_group_id = module.eks.node_security_group_id
    }
  }

  master_username             = "search"
  master_password             = random_password.db.result
  manage_master_user_password = false
  database_name               = "searchdb"

  storage_encrypted            = true
  deletion_protection          = true
  backup_retention_period      = 14
  performance_insights_enabled = true
  apply_immediately            = false

  tags = { Project = "search-service", Environment = "prod" }
}

# Store the full connection bundle for External Secrets Operator to sync.
resource "aws_secretsmanager_secret" "db" {
  name = "search-prod/db"
}
resource "aws_secretsmanager_secret_version" "db" {
  secret_id = aws_secretsmanager_secret.db.id
  secret_string = jsonencode({
    username = "search"
    password = random_password.db.result
    dbname   = "searchdb"
    host     = module.aurora.cluster_endpoint
    reader   = module.aurora.cluster_reader_endpoint
    port     = 5432
  })
}
