# Policy: read ONLY this service's secret.
resource "aws_iam_policy" "read_db_secret" {
  name = "search-app-read-db-secret"
  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect   = "Allow"
      Action   = ["secretsmanager:GetSecretValue", "secretsmanager:DescribeSecret"]
      Resource = [aws_secretsmanager_secret.db.arn]
    }]
  })
}

# IRSA role bound to the search:search-service ServiceAccount.
module "irsa_app" {
  source  = "terraform-aws-modules/iam/aws//modules/iam-role-for-service-accounts-eks"
  version = "~> 5.44"

  name = "search-app"
  oidc_providers = {
    main = {
      provider_arn               = module.eks.oidc_provider_arn
      namespace_service_accounts = ["search:search-service"]
    }
  }
  role_policy_arns = { read_secret = aws_iam_policy.read_db_secret.arn }
}
