variable "region" {
  type    = string
  default = "ap-south-1"
}

variable "cluster_name" {
  type    = string
  default = "search-prod"
}

variable "k8s_version" {
  type    = string
  default = "1.33"
}
