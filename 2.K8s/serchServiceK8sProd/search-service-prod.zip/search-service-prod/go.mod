module github.com/souvik/search-service

go 1.22

require (
	github.com/jackc/pgx/v5 v5.6.0
	github.com/prometheus/client_golang v1.19.1
)
