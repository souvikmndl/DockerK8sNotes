# search-service (production)

A Go document-search service (Postgres full-text search) built to run on AWS EKS with Aurora.
See **search-service-production-aws.md** for the full architecture & runbook.

## Layout
- `cmd/`, `internal/` — the Go service (writer/reader pools, structured logs, Prometheus metrics)
- `migrations/`       — golang-migrate SQL (up/down)
- `Dockerfile`        — multi-stage, distroless, non-root, RDS CA baked in
- `terraform/`        — VPC, EKS (v21), Aurora, ECR, IRSA, Secrets Manager
- `deploy/k8s/`       — hardened manifests (SA/IRSA, ExternalSecret, Deployment, HPA, PDB, NetworkPolicy, ServiceMonitor, Ingress, migrate Job)
- `deploy/argocd/`    — Argo CD Application (GitOps)
- `.github/workflows/`— CI: test → build → Trivy scan → cosign sign → push to ECR → bump deploy repo

## Quick start
1. `cd terraform && terraform init && terraform apply`
2. `aws eks update-kubeconfig --name search-prod --region ap-south-1`
3. Install platform add-ons (LB Controller, External Secrets, ExternalDNS, kube-prometheus-stack, Argo CD).
4. `kubectl apply -f deploy/argocd/application.yaml` and let GitOps sync.
5. Replace ACCOUNT_ID / REGION / CERT_ID / hostnames placeholders before first apply.

## Local dev
`go run ./cmd/server` with DB_USER / DB_PASSWORD / DB_NAME / DB_WRITER_HOST env vars set to a local Postgres.
